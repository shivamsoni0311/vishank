if(sessionStorage.getItem('DataLoaded') == null){
    sessionStorage.setItem('DataLoaded','True');

    sessionStorage.setItem('user1','user1');
    sessionStorage.setItem('user2','user2');

    sessionStorage.setItem('user1_balance','1000');
    sessionStorage.setItem('user2_balance','1000');
}

function myFunction(){
  var userid = document.getElementById("userid").value;
  var old_password = document.getElementById("old_password").value;
  var new_password = document.getElementById("new_password").value;
  var new_password_confirm = document.getElementById("new_password_confirm").value;

  if(new_password != new_password_confirm){
    console.log(new_password);
    console.log(new_password_confirm);
    alert('Password does not match');
    return;
  }

  if(sessionStorage.getItem(userid)!=null){
    if(sessionStorage.getItem(userid) != old_password){
      alert('Old password incorrect');
      return;
    }else{
      sessionStorage.setItem(userid,new_password);
      alert('Password updated');
      window.location.href = "Login.html"
    }
  }else{
    alert('user does not exist');
    return
  }


}
