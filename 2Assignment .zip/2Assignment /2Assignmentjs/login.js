if(sessionStorage.getItem('DataLoaded') == null){
    sessionStorage.setItem('DataLoaded','True');

    sessionStorage.setItem('user1','user1');
    sessionStorage.setItem('user2','user2');

    sessionStorage.setItem('user1_balance','1000');
    sessionStorage.setItem('user2_balance','1000');
}

function myFunction() {
    var x, text, y;

    // Get the value of the input field with id="numb" and id="text"
    var userid = document.getElementById("userid").value;
    var password = document.getElementById("password").value;

    if(sessionStorage.getItem(userid) != null){
        if(password == sessionStorage.getItem(userid)){
            console.log('login Successful');
            window.location.href = "Menu_options.html";
        }else{
            alert('invalid password');
        }
    }else{
        alert('user does not exit.');
    }

    // If x and y value matches as stated
    // if (x == "123" && y == "abc" ) {
    //     text = "Login Successful";
    //     //window.open("Assignment22.html");
    //     window.location.href = "Assignment2.html?username="+document.getElementById("numb").value;
    // } else {
    //     text = "Check your ID or Password fields ";
    // }
    // document.getElementById("demo").innerHTML = text;
}
